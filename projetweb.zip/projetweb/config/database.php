<?php
// Configuration de la base de données
define('DB_HOST', 'db4free.net'); // Serveur MySQL gratuit
define('DB_NAME', 'unitycs_db'); // Nom de la base de données
define('DB_USER', 'unitycs_admin'); // Nom d'utilisateur
define('DB_PASS', 'unitycs_admin'); // Mot de passe de la base de données

// Fonction pour afficher les erreurs de manière élégante
function displayDatabaseError($message) {
    $errorHtml = '<div style="position: fixed; top: 20px; right: 20px; max-width: 400px; background-color: #fff; border-left: 4px solid #dc3545; box-shadow: 0 2px 4px rgba(0,0,0,.1); padding: 15px; z-index: 9999;">';
    $errorHtml .= '<h4 style="margin: 0 0 10px 0; color: #dc3545;">Erreur de connexion</h4>';
    $errorHtml .= '<p style="margin: 0; color: #666;">' . htmlspecialchars($message) . '</p>';
    $errorHtml .= '</div>';
    echo $errorHtml;
    exit;
}

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8",
        DB_USER,
        DB_PASS,
        array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION)
    );
} catch(PDOException $e) {
    displayDatabaseError("Une erreur est survenue lors de la connexion à la base de données. Veuillez réessayer plus tard.");
}
?>