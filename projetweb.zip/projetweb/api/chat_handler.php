<?php
header('Content-Type: application/json');
require_once '../config/database.php';

session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Utilisateur non connecté']);
    exit;
}

// Fonction pour récupérer les messages d'un cours
function getMessages($courseId) {
    global $pdo;
    $stmt = $pdo->prepare(
        "SELECT m.*, u.username 
        FROM chat_messages m 
        JOIN users u ON m.user_id = u.id 
        WHERE m.course_id = ? 
        ORDER BY m.created_at ASC"
    );
    $stmt->execute([$courseId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fonction pour envoyer un message
function sendMessage($userId, $courseId, $message) {
    global $pdo;
    $stmt = $pdo->prepare(
        "INSERT INTO chat_messages (user_id, course_id, message) 
        VALUES (?, ?, ?)"
    );
    return $stmt->execute([$userId, $courseId, $message]);
}

// Fonction pour récupérer les cours de l'utilisateur
function getUserCourses($userId) {
    global $pdo;
    $stmt = $pdo->prepare(
        "SELECT c.* 
        FROM courses c 
        JOIN course_enrollments e ON c.id = e.course_id 
        WHERE e.user_id = ?"
    );
    $stmt->execute([$userId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Traiter les requêtes
$action = $_GET['action'] ?? '';

switch($action) {
    case 'get_messages':
        if (!isset($_GET['course_id'])) {
            http_response_code(400);
            echo json_encode(['error' => 'ID du cours manquant']);
            break;
        }
        $messages = getMessages($_GET['course_id']);
        echo json_encode(['messages' => $messages]);
        break;

    case 'send_message':
        $data = json_decode(file_get_contents('php://input'), true);
        if (!isset($data['course_id']) || !isset($data['message'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Données manquantes']);
            break;
        }
        if (sendMessage($_SESSION['user_id'], $data['course_id'], $data['message'])) {
            echo json_encode(['success' => true]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Erreur lors de l\'envoi du message']);
        }
        break;

    case 'get_courses':
        $courses = getUserCourses($_SESSION['user_id']);
        echo json_encode(['courses' => $courses]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Action non valide']);
}
?>