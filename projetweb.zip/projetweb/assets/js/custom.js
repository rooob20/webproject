$(document).ready(function(){
	"use strict";
    
        /*==================================
* Author        : "ThemeSine"
* Template Name : Listrace directory HTML Template
* Version       : 1.0
==================================== */




/*=========== TABLE OF CONTENTS ===========
1. Scroll To Top 
2. slick carousel
3. welcome animation support
4. feather icon
5. counter
======================================*/

    // 1. Scroll To Top 
		$(window).on('scroll',function () {
			if ($(this).scrollTop() > 600) {
				$('.return-to-top').fadeIn();
			} else {
				$('.return-to-top').fadeOut();
			}
		});
		$('.return-to-top').on('click',function(){
				$('html, body').animate({
				scrollTop: 0
			}, 1500);
			return false;
		});
	
	
	// 2. slick carousel

	    $(".testimonial-carousel").slick({
	        infinite: true,
	        centerMode: true,
	        autoplay:true,
	        slidesToShow: 5,
	        slidesToScroll: 3,
	        autoplaySpeed:1500,
	        // the magic
			responsive: [
				{

					breakpoint:1440,
					settings: {
					slidesToShow:3
					}

				},
				{

					breakpoint: 1024,
					settings: {
					slidesToShow:2,
					
					}

				}, 
				{

					breakpoint:991,
					settings: {
					slidesToShow:2,
					centerMode:false,
					}

				},
				{

					breakpoint:767,
					settings: {
					slidesToShow:1,
					}

				}
			]
	    });



    // 3. welcome animation support

        $(window).load(function(){
        	$(".welcome-hero-txt h2,.welcome-hero-txt p").removeClass("animated fadeInUp").css({'opacity':'0'});
            $(".welcome-hero-serch-box").removeClass("animated fadeInDown").css({'opacity':'0'});
        });

        $(window).load(function(){
        	$(".welcome-hero-txt h2,.welcome-hero-txt p").addClass("animated fadeInUp").css({'opacity':'0'});
            $(".welcome-hero-serch-box").addClass("animated fadeInDown").css({'opacity':'0'});
        });

	// 4. feather icon

		feather.replace();

	// 5. counter
		$(window).on('load', function(){	
			$('.counter').counterUp({
				delay: 10,
				time: 3000
			});	
		});

	//6.animation text home

	const text = "Vous etes dans le meilleur endroit, oui, c'est vraiement ici, c'est l'endroit dont vous revez toujours";
	let a = 0;
  
	function textHome() {
	  if (a < text.length) {
		document.getElementById("typing-text").innerHTML += text.charAt(a);
		a++;
		setTimeout(textHome, 50);
	  }
	}
  
	textHome();
		//cours
	const cours ="Cours"
	let b = 0;

	function titreCours(){
		if(b < cours.length){
			document.getElementById("cours").innerHTML += cours.charAt(b);
			b++;
			setTimeout(titreCours, 100);
		}

	}

	titreCours();

	//emploi

	const emploi = "Emploi"
	let c = 0;
	function titreEmploi(){
		if(b<emploi.length){
			document.getElementById("emploi").innerHTML += emploi.charAt(c);
			c++;
			setTimeout(titreEmploi, 100);
		}
	}

	titreEmploi();

	//evenement

	const evnt ="Evenement"
	let d = 0;
	function titreEvenement(){
		if(d <evnt.length){
			document.getElementById("evenement").innerHTML += evnt.charAt(d);
			d++;
			setTimeout(titreEvenement, 100);
		}
	}

	titreEvenement();

	//assistant

	const assis = "Assistant"
	let e = 0;
	function titreAssistant(){
		if(e < assis.length){
			document.getElementById("assistant").innerHTML += assis.charAt(e);
			e++;
			setTimeout(titreAssistant, 100);
		}
	}

	titreAssistant();

	//partenaires


	const partenaires = "Partenaires"
	let f = 0;
	function titrePartenaires(){
		if(f < partenaires.length){
			document.getElementById("partenaires").innerHTML += partenaires.charAt(f);
			f++;
			setTimeout(titrePartenaires, 100);
		}
	}

	titrePartenaires();


	//a la une

	const alaune ="A Propos"

	let g = 0;

	function aLaUne(){
		if (g < alaune.length){
			document.getElementById("alaune").innerHTML += alaune.charAt(g);
			g++;
			setTimeout(aLaUne, 100);
		}
	}

	aLaUne()

	//textAlaune

	const textAlaune = "Voyagez vers une nouvelle destination technologique avec nos formations et profitez d’offres exclusives sur nos services. Nous vous aidons à maîtriser les outils numériques essentiels grâce à un accompagnement personnalisé et des solutions innovantes. Rejoignez-nous pour transformer votre passion en expertise !"
	let h = 0;

	function txtAlaune(){
		if (h <textAlaune.length){
			document.getElementById("txtAlaune").innerHTML += textAlaune.charAt(h);
			h++;
			setTimeout(txtAlaune, 15);
		}
	}

	txtAlaune();

	//Apropos

	//engament

	const engagment = "Notre Engagement"
	let i = 0;

	function NotreEngagment(){
		if(i < engagment.length){
			document.getElementById("engagment").innerHTML += engagment.charAt(i);
			i++;

			setTimeout(NotreEngagment, 50);
		}
	}
	NotreEngagment();

	//support

	const supp = "Un Support Fiable et Rapide"
	let j = 0;

	function supportText(){
		if(j <supp.length){
			document.getElementById("supportTitre").innerHTML += supp.charAt(j);
			j++;

			setTimeout(supportText, 50);
		}
	}

	supportText();

	//numerique

	const num ="Technologie pour tous"
	let k = 0;

	function numeriquePourtous(){
		if(k <  num.length){
			document.getElementById("numerique").innerHTML +=num.charAt(k);
			k++;

			setTimeout(numeriquePourtous, 50);
		}
	}

	numeriquePourtous();

	//Nos cours

	const noscours ="Nos Services"
	let l = 0 ;

	function nosCoursTitle(){
		if (l < noscours.length){
			document.getElementById("noscours").innerHTML += noscours.charAt(l);
			l++;

			setTimeout(nosCoursTitle, 100);
		}
	}

	nosCoursTitle();


	// description nos cours

	const textnoscours = "Nous offrons une gamme complète de services technologiques pour vous accompagner dans votre transformation numérique. Que ce soit pour la création d’applications, la sécurisation de vos données ou le développement de votre présence en ligne, nous mettons notre expertise à votre disposition. Bénéficiez de solutions innovantes et d’un accompagnement personnalisé pour optimiser votre utilisation des nouvelles technologies."
	let m = 0;

	function texteNoscours(){
		if(m < textnoscours.length){
			document.getElementById("txtNoscours").innerHTML += textnoscours.charAt(m);
			m++;

			setTimeout(texteNoscours, 15);
		}
	}

	texteNoscours();

	//Text equipe

	const team = "Notre Equipe"

	let n = 0;

	function notreEquipe(){
		if( n  <team.length){
			document.getElementById("equipe").innerHTML += team.charAt(n);
			n++;

			setTimeout(notreEquipe,50);
		}
	}

	notreEquipe();


	//description notre equipe

	const descNotreequipe= "Derrière chaque innovation se trouve une équipe passionnée et dévouée. Composée d’experts en développement, en cybersécurité, en marketing digital et en assistance technique, notre équipe travaille avec engagement pour vous offrir des solutions performantes et adaptées à vos besoins. Ensemble, nous mettons notre savoir-faire au service de votre réussite, avec professionnalisme et créativité"
	let o = 0;

	function desciptionNotreEquipe(){
		if( o < descNotreequipe.length){
			document.getElementById("descEquipe").innerHTML += descNotreequipe.charAt(o);
			o++;

			setTimeout(desciptionNotreEquipe, 15);
		} 
	}

	desciptionNotreEquipe();

	//Rubly

	const rubly ="Rubly PLAISIR"
	let p = 0;

	function rublyPlaisir(){

		if(p <rubly.length){
			document.getElementById("rubly").innerHTML += rubly.charAt(p);
			p++;

		setTimeout(rublyPlaisir, 50);
		}
		
	}

	rublyPlaisir();

	//Wuidsson

	const wuidsson = "Wuidsson DELNE"
	let q = 0;

	function wuidssonDelne(){
		if (q < wuidsson.length){
		
		document.getElementById("wuidsson").innerHTML +=wuidsson.charAt(q);
		q++;

		setTimeout(wuidssonDelne, 50);
		}
	}

	wuidssonDelne();


	//rosemond

	const rosemond = "Rosemond LOUIS"
	let v = 0;

	function rosemondLouis(){
		if(v < rosemond.length){
			document.getElementById("rosemond").innerHTML += rosemond.charAt(v);
			v++;

			setTimeout(rosemondLouis, 50);
		}
	}

	rosemondLouis();

	//ricardo

	const ricardo = "Ricardo PLAISIR"
	let w = 0;

	function ricardoPlaisir(){
		if( w < ricardo.length){
			document.getElementById("ricardo").innerHTML += ricardo.charAt(w);

			w++;
			setTimeout(ricardoPlaisir, 50);
		}
	}

	ricardoPlaisir();
	//Rebecca

	const rebecca = "Rebecca DORCEAN"
	let r = 0;

	function rebeccaDorcean (){
		if (r < rebecca.length){
			document.getElementById("rebecca").innerHTML += rebecca.charAt(r);
			r++;

			setTimeout(rebeccaDorcean, 50);
		}
	}

	rebeccaDorcean();


	//jean denis

	const jeandenis = "Jean Denis LAGUERRE"
	let s = 0;

	function jeanDenisLaguerre(){
		if(s < jeandenis.length){
			document.getElementById("jeandenis").innerHTML += jeandenis.charAt(s);
			s++;

			setTimeout(jeanDenisLaguerre, 50);
		}
	}

	jeanDenisLaguerre();

	//ignace

	const wilkerce ="Wilkerce IGNACE"
	let t = 0;

	function ignaceWilkerce(){
		if(t < wilkerce.length){
			document.getElementById("wilkerce").innerHTML += wilkerce.charAt(t);
			t++;

			setTimeout(ignaceWilkerce,50);
		}
	}

	ignaceWilkerce();


	//marieannee

	const marieannee = "Marie Année CADET"
	let u = 0;
	 
	function marieAnneeCadet(){
		if( u < marieannee.length){
			document.getElementById("marieannee").innerHTML += marieannee.charAt(u);
			u++;

			setTimeout(marieAnneeCadet, 50);
		}
	}

	marieAnneeCadet();
});
