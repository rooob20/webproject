<?php
require_once 'config/database.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    // Validation
    $errors = [];
    if (empty($email) || empty($password)) {
        $errors[] = "Tous les champs sont requis";
    }

    if (empty($errors)) {
        try {
            // Vérification des identifiants
            $stmt = $pdo->prepare("SELECT id, username, password FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                // Création de la session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                
                // Redirection vers la page d'accueil
                header('Location: index.html');
                exit;
            } else {
                $errors[] = "Email ou mot de passe incorrect";
            }
        } catch (PDOException $e) {
            $errors[] = "Erreur de base de données: " . $e->getMessage();
        }
    }

    if (!empty($errors)) {
        // Redirection vers la page de connexion avec les erreurs
        $error_string = urlencode(implode(", ", $errors));
        header("Location: login.html?error=" . $error_string);
        exit;
    }
} else {
    // Si ce n'est pas une requête POST, rediriger vers le formulaire
    header('Location: login.html');
    exit;
}