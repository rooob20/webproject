<?php
session_start();

// Vérifier si l'utilisateur est connecté
$isLoggedIn = isset($_SESSION['user_id']);
$username = $isLoggedIn ? $_SESSION['username'] : '';

// Renvoyer les informations de session au format JSON
header('Content-Type: application/json');
echo json_encode([
    'isLoggedIn' => $isLoggedIn,
    'username' => $username
]);